#include <WiFi.h>
#include <PubSubClient.h>
#include "DHT.h"

#define DHTPIN 4
#define DHTTYPE DHT22

// ---- Change only these for Node 2 / Node 3 ----
const char* NODE_NAME = "node2";
const char* TOPIC     = "wsm_mesh/node2";
// -----------------------------------------------

const char* ssid       = "Wokwi-GUEST";
const char* password   = "";
const char* mqttServer = "broker.hivemq.com";
const int   mqttPort   = 1883;

DHT dht(DHTPIN, DHTTYPE);
WiFiClient espClient;
PubSubClient mqtt(espClient);

void connectWiFi() {
  Serial.print("Connecting to WiFi");
  WiFi.begin(ssid, password, 6);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected");
}

void connectMQTT() {
  while (!mqtt.connected()) {
    Serial.print("Connecting to HiveMQ...");
    String clientId = String("wsm-") + NODE_NAME + "-" + String(random(0xffff), HEX);
    if (mqtt.connect(clientId.c_str())) {
      Serial.println("connected");
    } else {
      Serial.print("failed, rc=");
      Serial.println(mqtt.state());
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  dht.begin();
  connectWiFi();
  mqtt.setServer(mqttServer, mqttPort);
}

void loop() {
  if (!mqtt.connected()) connectMQTT();
  mqtt.loop();

  float t = dht.readTemperature();
  float h = dht.readHumidity();

  if (isnan(t) || isnan(h)) {
    Serial.println("DHT22 reading failed!");
  } else {
    char payload[32];
    snprintf(payload, sizeof(payload), "%.1f,%.1f", t, h);
    mqtt.publish(TOPIC, payload);
    Serial.print("Published to ");
    Serial.print(TOPIC);
    Serial.print(" : ");
    Serial.println(payload);
  }
  delay(5000);
}